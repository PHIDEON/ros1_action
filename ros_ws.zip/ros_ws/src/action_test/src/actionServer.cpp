#include "actionlib/server/simple_action_server.h"  
#include "action_test/washAction.h"  
#include "ros/ros.h"  
  
void ExecuteCallback(const action_test::washGoalConstPtr& goalptr,actionlib::SimpleActionServer<action_test::washAction>* ptr)  
{  
    ros::Rate r(1);  
    action_test::washFeedback feedback;  
    ROS_INFO("final aim:%d\n\t",goalptr->targeted_washed_dishes);  
    // submit feedback  
    for(int i=0;i<=goalptr->targeted_washed_dishes;i++)  
    {  
        feedback.now_number_washed_dished = i;  
        ptr->publishFeedback(feedback);  
        r.sleep();  
    }  
    ROS_INFO("finished number:%d\n\t",feedback.now_number_washed_dished);  
    ptr->setSucceeded();  
}  
  
int main(int argc, char* argv[])  
{  
    // localize  
    setlocale(LC_ALL,"");  
    // initial the node  
    ros::init(argc,argv,"actionServer");  
    // create the ActionServer-type object  
    ros::NodeHandle nh;  
    actionlib::SimpleActionServer<action_test::washAction> obj(nh,"chatter",boost::bind(&ExecuteCallback,_1,&obj),false);  
    obj.start();  
    ros::spin();  
    return 0;  
}
