#include "actionlib/client/simple_action_client.h"  
#include "action_test/washAction.h"  
#include "ros/ros.h"  
  
void SimpleDoneCallbackFunc(const actionlib::SimpleClientGoalState& state,const action_test::washResultConstPtr& result)  
{  
    ROS_INFO("finish!\n\t"); 
    // state中有两个成员enumerate类型的state_和string类型的说明文本text_  
    ROS_INFO("Now State:%d\n\t",state.state_);  
    ROS_INFO("total_washed_dished:%d\n\t",result->total_washed_dished);  
    ros::shutdown(); // shut down the operation of node explicitly  
}  
void SimpleActiveCallbackFunc()  
{  
    ROS_INFO("the node is active!\n\t");  
}  
void SimpleFeedbackCallbackFunc(const action_test::washFeedbackConstPtr& feedback)  
{  
    ROS_INFO("now_number_washed_dished:%d\n\t",feedback->now_number_washed_dished);  
}  
  
int main(int argc,char* argv[])  
{  
    // localize  
    setlocale(LC_ALL,"");  
    // initial the node  
    ros::init(argc,argv,"actionClient");  
    // define ActionClient-type object  
    ros::NodeHandle nh;  
    actionlib::SimpleActionClient<action_test::washAction> obj(nh,"chatter",true);  
    // wait until the server appears  
    ROS_INFO("waiting for action server to start.");  
    obj.waitForServer();  
    ROS_INFO("Action server started, sending goal.");  
    // pack data  
    action_test::washGoal goal;  
    goal.targeted_washed_dishes = 10;  
    // submit data to ActionServer  
    obj.sendGoal(goal,&SimpleDoneCallbackFunc,&SimpleActiveCallbackFunc,&SimpleFeedbackCallbackFunc);  
    // loop continueously to receive information  
    ros::spin(); // when finishing goal, shutdown() will end the node  
    return 0;  
} 
